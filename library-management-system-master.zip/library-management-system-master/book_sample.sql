INSERT INTO `Booklist`
VALUES	('Magnolia Table, Volume 2: A Collection of Recipes for Gathering','978-0062820181','Joanna Gaines','William Morrow Cookbooks (April 7, 2020)',3,3,NULL),
	('Computer Systems: A Programmer\'s Perspective (3rd Edition)','978-0134123837','Randal E. Bryant, David R. O\'Hallaron','Pearson; 3 edition (July 6, 2015)',4,4,NULL),
	('Introduction to Algorithms, 3rd Edition','978-0262033848','Thomas H. Cormen, Charles E. Leiserson, Ronald L. Rivest , Clifford Stein','The MIT Press; 3rd edition (July 31, 2009)',2,2,NULL),
	('Camino Winds','978-0385545938','John Grisham','Doubleday (April 28, 2020)',3,3,NULL),
	('Eye of the Elephant Pa','978-0395680902','Delia Owens','Mariner (October 29, 1993)',2,2,NULL),
	('Where the Crawdads Sing','978-0735219090','Delia Owens','G.P. Putnam\'s Sons; Later Printing edition (August 14, 2018)',0,0,''),
	('The Ballad of Songbirds and Snakes (A Hunger Games Novel)','978-1338635171','Suzanne Collins','Scholastic Press (May 19, 2020)',0,0,'lost'),
	('Untamed','978-1984801258','Glennon Doyle','The Dial Press (March 10, 2020)',1,1,'renew'),
	('Normal People: A Novel','978-1984822185','Sally Rooney','Hogarth; Reprint edition (February 18, 2020)',1,1,NULL);
